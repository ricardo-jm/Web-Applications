<?php

/* Define username and password */
$Username = "Ricardo";
$Password = "password";
